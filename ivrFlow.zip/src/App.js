import React from 'react';
import "./App.css";
import "reactflow/dist/style.css";
import Home from "./Pages/Homepage/Home";

function App() {
  return (
    <>
      <Home />
    </>
  );
}

export default App;
