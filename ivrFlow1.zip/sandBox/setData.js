setData((prevData) => ({
    ...prevData,

    data: parentNode.data,
  }));

  setData((prevData) => ({
    ...prevData,
    data: {
      ...prevData.data,
      
    }
  }));
